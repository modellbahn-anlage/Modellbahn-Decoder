V1.0, 25.09.2007:

Elektrisch wie OpenDecoder,

jedoch sind die LEDs fest angeschlossen
(Ausgang aktiv LOW)

ProgLED fehlt -> wird durch Lichtspiel ersetzt
Reset fehlt -> macht Chip intern
Jumper fehlt -> macht Chip immer
